﻿using UnityEngine;
using System.Collections;
using System.Net.Sockets;
using System.Threading;
using System.IO;
using System;
using UnityEngine.UI;

public class quad_controller : MonoBehaviour {
	public GameObject drone;
	public GameObject fader;
	public GameObject errorPanel;
	public Text weatherText;
	public Text droneText;

	private TcpListener listener;
	private TcpClient client;
	private Socket soc;
	private Vector3 newPosition;
	private bool change = false;
	private bool error = false;

	private string temp = "--";
	private string pressure = "--";
	private string humidity = "--";
	private string wind_speed = "--";
	private string wind_degree = "--";
	private string longitude = "--";
	private string latitude = "--";
	private string accX = "--";
	private string accY = "--";
	private string accZ = "--";
	private string oriX = "--";
	private string oriY = "--";
	private string oriZ = "--";
	string[] data = new string[13];

	void Start () {
		new Thread(new ThreadStart(Client)).Start();
	}

	public void Client() {
		try {
			client = new TcpClient();
			IAsyncResult result = client.BeginConnect("192.168.3.96", 8000, null, null);
			bool success = result.AsyncWaitHandle.WaitOne(TimeSpan.FromSeconds(1));
			while(!success) {
				error = true;
				Debug.LogError("connection timed out, reconnecting again...");
				client = new TcpClient();
				result = client.BeginConnect("192.168.3.96", 8000, null, null);
				success = result.AsyncWaitHandle.WaitOne(TimeSpan.FromSeconds(1));
			}
			error = false;
			Debug.Log("Connected...");
			Stream s = client.GetStream();
			StreamReader sr = new StreamReader(s);
			string line = sr.ReadLine();
			while(line != null) {
				Debug.Log(line);
				data = line.Split(',');
				temp = data[0];
				pressure = data[1];
				humidity = data[2];
				wind_speed = data[3];
				wind_degree = data[4];
				latitude = data[5];
				longitude = data[6];
				accX = data[7];
				accY = data[8];
				accZ = data[9];
				oriX = data[10];
				oriY = data[11];
				oriZ = data[12];

				float accelerationX = float.Parse(accX);
				float accelerationY = float.Parse(accY);
				float accelerationZ = float.Parse(accZ);
				newPosition = new Vector3(0, 0, 0);

				if(accelerationX > -7 && accelerationX < 7) {
					newPosition += new Vector3(accelerationX, 0, 0);
					change = true;
				}
				if(accelerationY > -7 && accelerationY < 7) {
					newPosition += new Vector3(0, accelerationY, 0);
					change = true;
				}
				if(accelerationZ > -7 && accelerationZ < 7) {
					newPosition += new Vector3(0, 0, accelerationZ);
					change = true;
				}
				line = sr.ReadLine();
			}
			s.Close();
			Debug.Log("Connection Ended");
		} catch(SocketException e) {
			Debug.LogError(e.Message);
			error = true;
		} catch(Exception e) {
			Debug.LogError(e.ToString());
			error = true;
		}
		finally {
			client.Close();
		}
	}

	void Update () {
		if(change) {
			drone.transform.position = drone.transform.position + newPosition;
			change = false;
		}
		fader.SetActive(error);
		errorPanel.SetActive(error);
		if (data.Length > 0) {
			weatherText.text = string.Format("Temp: {0:S}\nPressure: {1:S}\nHumidity: {2:S}\nWind Speed: {3:S}\nWind Degree: {4:S}",
			                                 temp, pressure, humidity, wind_speed, wind_degree);
			double acceleration = Math.Sqrt((double.Parse(accX) * double.Parse(accX)) + (double.Parse(accY) * double.Parse(accY)) + (double.Parse(accZ) * double.Parse(accZ)));
			double orientation = Math.Sqrt((double.Parse(oriX) * double.Parse(oriX)) + (double.Parse(oriY) * double.Parse(oriY)) + (double.Parse(oriZ) * double.Parse(oriZ)));
			droneText.text = string.Format("Speed: {0:F3}\nAcceleration: {1:F3}\nOrientation: {2:F3}\nHeight: {3:S}\nLongitude: {4:S}\nLatitude: {5:S}",
			                                 acceleration / 2 * 3, acceleration, orientation, "--", longitude, latitude);
		}
	}
}